"""
Inventory management sub-package.

Includes:
- Item classes (with inheritance)
- Inventory operations
- Persistence tools
"""
